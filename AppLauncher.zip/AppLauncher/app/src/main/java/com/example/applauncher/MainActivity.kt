package com.example.applauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private val SLOTS = 10
    private val slots = Array(SLOTS) { "" }          // имена пакетов
    private lateinit var grid: LinearLayout
    private lateinit var note: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("p", Context.MODE_PRIVATE).getString("slots", "") ?: ""
        saved.split("|").take(SLOTS).forEachIndexed { i, s -> slots[i] = s }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Мульти-запуск"; textSize = 22f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#1D2330")); setPadding(0, 0, 0, dp(16))
        })
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(grid)

        val fab = TextView(this).apply {
            text = "+"; textSize = 36f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2468F2")) }
            setOnClickListener { val i = slots.indexOf(""); if (i >= 0) pick(i) else note.text = "Все ячейки заняты. Удерживайте плитку, чтобы убрать приложение." }
        }
        root.addView(fab, LinearLayout.LayoutParams(dp(64), dp(64)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(20) })

        val run = Button(this).apply {
            text = "Запустить все"; isAllCaps = false; textSize = 17f; setTextColor(Color.WHITE)
            background = shape(Color.parseColor("#2468F2"), 12)
            setOnClickListener { launchAll() }
        }
        root.addView(run, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(20) })

        note = TextView(this).apply { textSize = 14f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }
        root.addView(note)

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.WHITE); addView(root) })
        render()
    }

    private fun save() = getSharedPreferences("p", Context.MODE_PRIVATE).edit().putString("slots", slots.joinToString("|")).apply()

    private fun render() {
        grid.removeAllViews()
        for (r in 0 until SLOTS / 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..1) {
                val i = r * 2 + c
                row.addView(tile(i), LinearLayout.LayoutParams(0, dp(112), 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            }
            grid.addView(row)
        }
    }

    private fun tile(i: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8))
            background = shape(Color.parseColor("#E8E8EE"), 14, Color.parseColor("#D9D9E1"))
        }
        val pkg = slots[i]
        if (pkg.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Добавить\nприложение"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#1D2330"))
            })
            box.setOnClickListener { pick(i) }
        } else {
            try {
                val info = packageManager.getApplicationInfo(pkg, 0)
                box.addView(ImageView(this).apply { setImageDrawable(packageManager.getApplicationIcon(info)) }, LinearLayout.LayoutParams(dp(52), dp(52)))
                box.addView(TextView(this).apply {
                    text = packageManager.getApplicationLabel(info); textSize = 14f; gravity = Gravity.CENTER
                    maxLines = 1; setTextColor(Color.parseColor("#1D2330")); setPadding(0, dp(6), 0, 0)
                })
            } catch (e: Exception) {
                slots[i] = ""; save()                        // приложение удалено с телефона
                return tile(i)
            }
            box.setOnClickListener { pick(i) }               // нажатие — заменить
            box.setOnLongClickListener { slots[i] = ""; save(); render(); true }
        }
        return box
    }

    /** Список установленных приложений */
    private fun pick(slot: Int) {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(10), dp(16), dp(10))
                }
                row.addView(ImageView(this@MainActivity).apply { setImageDrawable(apps[p].loadIcon(pm)) }, LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(TextView(this@MainActivity).apply {
                    text = apps[p].loadLabel(pm); textSize = 17f; setPadding(dp(16), 0, 0, 0)
                })
                return row
            }
        }
        AlertDialog.Builder(this).setTitle("Выберите приложение")
            .setAdapter(adapter) { _, which -> slots[slot] = apps[which].activityInfo.packageName; save(); render() }
            .setNegativeButton("Отмена", null).show()
    }

    /** Запуск всех выбранных приложений подряд */
    private fun launchAll() {
        val pkgs = slots.filter { it.isNotEmpty() }
        if (pkgs.isEmpty()) { note.text = "Сначала добавьте приложения."; return }
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this).setTitle("Нужно разрешение")
                .setMessage("Чтобы запускать несколько приложений сразу, включите «Поверх других приложений» для этого приложения.")
                .setPositiveButton("Открыть настройки") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                .setNegativeButton("Отмена", null).show()
            return
        }
        val h = Handler(Looper.getMainLooper())
        pkgs.forEachIndexed { i, p ->
            h.postDelayed({
                packageManager.getLaunchIntentForPackage(p)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(it)
                }
            }, i * 800L)
        }
    }
}

package com.example.grandmulti

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.View

/** Одна ячейка: своя копия игры на своём виртуальном экране размером с плитку. */
class Slot(private val ctx: Context, val index: Int) {
    companion object { const val DPI = 240 }

    var pkg: String? = null
    var w = 0; var h = 0
    private var vd: VirtualDisplay? = null
    private var surface: Surface? = null
    private val dummy = Surface(SurfaceTexture(false).apply { setDefaultBufferSize(320, 320) })

    val running get() = vd != null
    private val displayId get() = vd?.display?.displayId ?: -1

    fun onSurface(s: Surface, w: Int, h: Int) { surface = s; this.w = w; this.h = h; vd?.surface = s }
    fun detach() { surface = null; vd?.surface = dummy }
    fun resize(w: Int, h: Int) { this.w = w; this.h = h; vd?.resize(w, h, DPI) }

    fun start() {
        val p = pkg ?: return
        val s = surface ?: return
        if (vd == null) {
            vd = ctx.getSystemService(DisplayManager::class.java).createVirtualDisplay(
                "grand-slot-$index", w, h, DPI, s,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            )
        }
        val comp = ctx.packageManager.getLaunchIntentForPackage(p)?.component?.flattenToShortString() ?: return
        val id = displayId
        Thread { runCatching { Shell.exec("am start --display $id -n $comp") } }.start()
    }

    fun stop() {
        pkg?.let { p -> Thread { runCatching { Shell.exec("am force-stop $p") } }.start() }
        vd?.release(); vd = null
    }

    /** Пересылает касания из плитки в игру (мультитач поддерживается). */
    fun touch(ev: MotionEvent, v: View) {
        if (vd == null || v.width == 0) return
        val sx = w.toFloat() / v.width; val sy = h.toFloat() / v.height
        val n = ev.pointerCount
        val props = Array(n) { MotionEvent.PointerProperties().also { p -> ev.getPointerProperties(it, p) } }
        val coords = Array(n) {
            MotionEvent.PointerCoords().also { c -> ev.getPointerCoords(it, c); c.x *= sx; c.y *= sy }
        }
        val e = MotionEvent.obtain(
            ev.downTime, ev.eventTime, ev.action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        runCatching { Injector.send(e, displayId) }
        e.recycle()
    }
}

package com.example.grandmulti

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager

/** Держит приложение живым, пока окна афкшат в фоне. */
class KeepAliveService : Service() {
    private var wl: PowerManager.WakeLock? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("afk", "AFK", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "afk")
            .setContentTitle("Grand Multi работает").setContentText("Окна в AFK")
            .setSmallIcon(android.R.drawable.ic_media_play).build())
        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "grandmulti:afk").apply { acquire() }
        return START_STICKY
    }
    override fun onDestroy() { wl?.release() }
    override fun onBind(p0: Intent?): IBinder? = null
}

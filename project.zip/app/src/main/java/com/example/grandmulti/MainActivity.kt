package com.example.grandmulti

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
    private val slots by lazy { List(10) { Slot(this, it) } }
    private val labels = arrayOfNulls<TextView>(10)
    private val texs = arrayOfNulls<TextureView>(10)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        startForegroundService(Intent(this, KeepAliveService::class.java))

        Shizuku.addRequestPermissionResultListener { _, r -> if (r == 0) runOnUiThread { startAll() } }
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != 0) Shizuku.requestPermission(1)

        val prefs = getSharedPreferences("slots", MODE_PRIVATE)
        slots.forEach { it.pkg = prefs.getString("pkg${it.index}", null) }

        // Сетка 5 x 2 на весь экран, плитки впритык
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        for (r in 0..1) {
            val row = LinearLayout(this)
            for (c in 0..4) row.addView(tile(slots[r * 5 + c]),
                LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(1, 1, 1, 1) })
            root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
    }

    override fun onResume() { super.onResume(); startAll() }

    private fun startAll() {
        if (Shell.ready()) slots.forEach { if (it.pkg != null && !it.running) it.start() }
    }

    private fun tile(s: Slot): View {
        val f = FrameLayout(this).apply { setBackgroundColor(0xFF1D2027.toInt()) }
        val tv = TextureView(this)
        texs[s.index] = tv
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                s.onSurface(Surface(st), w, h)
                if (s.pkg != null && Shell.ready()) s.start()
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = s.resize(w, h)
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { s.detach(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv.setOnTouchListener { v, e -> s.touch(e, v); true }
        f.addView(tv, -1, -1)

        val label = TextView(this).apply {
            text = "Добавить\nприложение"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            visibility = if (s.pkg == null) View.VISIBLE else View.GONE
            setOnClickListener { pick(s) }
        }
        labels[s.index] = label
        f.addView(label, -1, -1)

        // Маленькая кнопка меню в левом нижнем углу плитки
        val menu = TextView(this).apply {
            text = "⋯"; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            setBackgroundColor(0x66000000); setOnClickListener { menu(s) }
        }
        f.addView(menu, FrameLayout.LayoutParams(dp(34), dp(26), Gravity.BOTTOM or Gravity.START))
        return f
    }

    private fun menu(s: Slot) {
        val items = arrayOf("Сменить копию", "Перезапустить", "Убрать из ячейки", "Запустить все")
        AlertDialog.Builder(this).setTitle("Ячейка ${s.index + 1}: ${s.pkg ?: "пусто"}")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> pick(s)
                    1 -> { s.stop(); if (Shell.ready()) s.start() else toast("Включи Shizuku") }
                    2 -> { s.stop(); s.pkg = null; save(s); labels[s.index]?.visibility = View.VISIBLE }
                    3 -> startAll()
                }
            }.show()
    }

    private fun pick(s: Slot) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .sortedBy { if (it.first.contains("grand", true)) "0${it.first}" else "1${it.first}" }
        AlertDialog.Builder(this).setTitle("Выбери копию игры")
            .setItems(apps.map { "${it.first}\n${it.second}" }.toTypedArray()) { _, i ->
                s.stop(); s.pkg = apps[i].second; save(s)
                labels[s.index]?.visibility = View.GONE
                if (Shell.ready()) s.start() else toast("Включи Shizuku")
            }.show()
    }

    private fun save(s: Slot) =
        getSharedPreferences("slots", MODE_PRIVATE).edit().putString("pkg${s.index}", s.pkg).apply()

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
